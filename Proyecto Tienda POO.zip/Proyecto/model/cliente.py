class Cliente:
    def __init__(self, id=None, nombre="", contacto="", direccion=""):
        self.id = id
        self.nombre = nombre
        self.contacto = contacto
        self.direccion = direccion

    def validar(self):
        return bool(self.nombre and self.nombre.strip())

    def __str__(self):
        return self.nombre