from datetime import date

class Compra:
    def __init__(self, id=None, fecha=None, proveedor_id=0, producto_id=0, cantidad=0, precio_total=0.0):
        self.id = id
        self.fecha = fecha or date.today()
        self.proveedor_id = proveedor_id
        self.producto_id = producto_id
        self.cantidad = cantidad
        self.precio_total = precio_total

    def validar(self):
        return self.fecha and self.cantidad > 0 and self.precio_total > 0