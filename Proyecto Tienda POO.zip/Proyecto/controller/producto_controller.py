from dao.producto_dao import ProductoDAO
from model.producto import Producto

class ProductoController:
    @staticmethod
    def crear_producto(producto):
        ProductoDAO.insertar(producto)

    @staticmethod
    def obtener_productos():
        return ProductoDAO.consultar_todos()

    @staticmethod
    def actualizar_producto(producto):
        ProductoDAO.actualizar(producto)

    @staticmethod
    def eliminar_producto(id):
        ProductoDAO.eliminar(id)