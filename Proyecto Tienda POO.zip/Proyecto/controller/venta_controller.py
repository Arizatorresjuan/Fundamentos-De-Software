from dao.venta_dao import VentaDAO
from model.venta import Venta
from util.stock_insuficiente_exception import StockInsuficienteException

class VentaController:
    @staticmethod
    def crear_venta(venta):
        if not venta.validar():
            raise ValueError("Datos de venta inválidos")
        VentaDAO.insertar(venta)  # Incluye verificación y actualización de stock en el DAO

    @staticmethod
    def obtener_ventas():
        return VentaDAO.consultar_todos()

    @staticmethod
    def actualizar_venta(venta):
        if not venta.validar():
            raise ValueError("Datos de venta inválidos")
        VentaDAO.actualizar(venta)

    @staticmethod
    def eliminar_venta(id):
        VentaDAO.eliminar(id)