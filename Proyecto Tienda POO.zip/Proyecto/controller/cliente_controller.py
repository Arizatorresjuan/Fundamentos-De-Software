from dao.cliente_dao import ClienteDAO
from model.cliente import Cliente

class ClienteController:
    @staticmethod
    def crear_cliente(cliente):
        if not cliente.validar():
            raise ValueError("Datos de cliente inválidos")
        ClienteDAO.insertar(cliente)

    @staticmethod
    def obtener_clientes():
        return ClienteDAO.consultar_todos()

    @staticmethod
    def actualizar_cliente(cliente):
        if not cliente.validar():
            raise ValueError("Datos de cliente inválidos")
        ClienteDAO.actualizar(cliente)

    @staticmethod
    def eliminar_cliente(id):
        ClienteDAO.eliminar(id)