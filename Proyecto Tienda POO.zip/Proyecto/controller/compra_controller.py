from dao.compra_dao import CompraDAO
from model.compra import Compra

class CompraController:
    @staticmethod
    def crear_compra(compra):
        if not compra.validar():
            raise ValueError("Datos de compra inválidos")
        CompraDAO.insertar(compra)  # Incluye actualización de stock en el DAO

    @staticmethod
    def obtener_compras():
        return CompraDAO.consultar_todos()

    @staticmethod
    def actualizar_compra(compra):
        if not compra.validar():
            raise ValueError("Datos de compra inválidos")
        CompraDAO.actualizar(compra)

    @staticmethod
    def eliminar_compra(id):
        CompraDAO.eliminar(id)