from dao.proveedor_dao import ProveedorDAO
from model.proveedor import Proveedor

class ProveedorController:
    @staticmethod
    def crear_proveedor(proveedor):
        if not proveedor.validar():
            raise ValueError("Datos de proveedor inválidos")
        ProveedorDAO.insertar(proveedor)

    @staticmethod
    def obtener_proveedores():
        return ProveedorDAO.consultar_todos()

    @staticmethod
    def actualizar_proveedor(proveedor):
        if not proveedor.validar():
            raise ValueError("Datos de proveedor inválidos")
        ProveedorDAO.actualizar(proveedor)

    @staticmethod
    def eliminar_proveedor(id):
        ProveedorDAO.eliminar(id)