from util.db_connection import DBConnection
from model.compra import Compra

class CompraDAO:
    @staticmethod
    def insertar(compra):
        if not compra.validar():
            raise ValueError("Datos de compra inválidos")
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                sql = "INSERT INTO Compra (fecha, proveedor_id, producto_id, cantidad, precio_total) VALUES (%s, %s, %s, %s, %s)"
                cursor.execute(sql, (compra.fecha, compra.proveedor_id, compra.producto_id, compra.cantidad, compra.precio_total))
                connection.commit()
                compra.id = cursor.lastrowid
                # Actualizar stock del producto: incrementar
                cursor.execute("UPDATE Producto SET stock = stock + %s WHERE id = %s", (compra.cantidad, compra.producto_id))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def consultar_todos():
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM Compra")
                results = cursor.fetchall()
                return [Compra(**row) for row in results]
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def actualizar(compra):
        if not compra.validar():
            raise ValueError("Datos de compra inválidos")
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                sql = "UPDATE Compra SET fecha=%s, proveedor_id=%s, producto_id=%s, cantidad=%s, precio_total=%s WHERE id=%s"
                cursor.execute(sql, (compra.fecha, compra.proveedor_id, compra.producto_id, compra.cantidad, compra.precio_total, compra.id))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def eliminar(id):
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("DELETE FROM Compra WHERE id=%s", (id,))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def consultar_por_id(id):
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM Compra WHERE id=%s", (id,))
                row = cursor.fetchone()
                return Compra(**row) if row else None
        finally:
            DBConnection.close_connection(connection)