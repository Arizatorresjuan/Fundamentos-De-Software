from util.db_connection import DBConnection
from model.cliente import Cliente

class ClienteDAO:
    @staticmethod
    def insertar(cliente):
        if not cliente.validar():
            raise ValueError("Datos de cliente inválidos")
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                sql = "INSERT INTO Cliente (nombre, contacto, direccion) VALUES (%s, %s, %s)"
                cursor.execute(sql, (cliente.nombre, cliente.contacto, cliente.direccion))
                connection.commit()
                cliente.id = cursor.lastrowid
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def consultar_todos():
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM Cliente")
                results = cursor.fetchall()
                return [Cliente(**row) for row in results]
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def actualizar(cliente):
        if not cliente.validar():
            raise ValueError("Datos de cliente inválidos")
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                sql = "UPDATE Cliente SET nombre=%s, contacto=%s, direccion=%s WHERE id=%s"
                cursor.execute(sql, (cliente.nombre, cliente.contacto, cliente.direccion, cliente.id))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def eliminar(id):
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("DELETE FROM Cliente WHERE id=%s", (id,))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def consultar_por_id(id):
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM Cliente WHERE id=%s", (id,))
                row = cursor.fetchone()
                return Cliente(**row) if row else None
        finally:
            DBConnection.close_connection(connection)