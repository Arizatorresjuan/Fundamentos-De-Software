from util.db_connection import DBConnection
from model.venta import Venta
from dao.producto_dao import ProductoDAO
from util.stock_insuficiente_exception import StockInsuficienteException

class VentaDAO:
    @staticmethod
    def insertar(venta):
        if not venta.validar():
            raise ValueError("Datos de venta inválidos")
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                # Verificar stock antes de insertar
                producto = ProductoDAO.consultar_por_id(venta.producto_id)
                if producto.stock < venta.cantidad:
                    raise StockInsuficienteException()
                
                sql = "INSERT INTO Venta (fecha, cliente_id, producto_id, cantidad, precio_total) VALUES (%s, %s, %s, %s, %s)"
                cursor.execute(sql, (venta.fecha, venta.cliente_id, venta.producto_id, venta.cantidad, venta.precio_total))
                connection.commit()
                venta.id = cursor.lastrowid
                # Actualizar stock del producto: decrementar
                cursor.execute("UPDATE Producto SET stock = stock - %s WHERE id = %s", (venta.cantidad, venta.producto_id))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def consultar_todos():
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM Venta")
                results = cursor.fetchall()
                return [Venta(**row) for row in results]
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def actualizar(venta):
        if not venta.validar():
            raise ValueError("Datos de venta inválidos")
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                sql = "UPDATE Venta SET fecha=%s, cliente_id=%s, producto_id=%s, cantidad=%s, precio_total=%s WHERE id=%s"
                cursor.execute(sql, (venta.fecha, venta.cliente_id, venta.producto_id, venta.cantidad, venta.precio_total, venta.id))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def eliminar(id):
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("DELETE FROM Venta WHERE id=%s", (id,))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def consultar_por_id(id):
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM Venta WHERE id=%s", (id,))
                row = cursor.fetchone()
                return Venta(**row) if row else None
        finally:
            DBConnection.close_connection(connection)