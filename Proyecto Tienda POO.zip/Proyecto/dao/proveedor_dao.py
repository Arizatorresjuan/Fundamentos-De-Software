from util.db_connection import DBConnection
from model.proveedor import Proveedor

class ProveedorDAO:
    @staticmethod
    def insertar(proveedor):
        if not proveedor.validar():
            raise ValueError("Datos de proveedor inválidos")
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                sql = "INSERT INTO Proveedor (nombre, contacto, direccion) VALUES (%s, %s, %s)"
                cursor.execute(sql, (proveedor.nombre, proveedor.contacto, proveedor.direccion))
                connection.commit()
                proveedor.id = cursor.lastrowid
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def consultar_todos():
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM Proveedor")
                results = cursor.fetchall()
                return [Proveedor(**row) for row in results]
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def actualizar(proveedor):
        if not proveedor.validar():
            raise ValueError("Datos de proveedor inválidos")
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                sql = "UPDATE Proveedor SET nombre=%s, contacto=%s, direccion=%s WHERE id=%s"
                cursor.execute(sql, (proveedor.nombre, proveedor.contacto, proveedor.direccion, proveedor.id))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def eliminar(id):
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("DELETE FROM Proveedor WHERE id=%s", (id,))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def consultar_por_id(id):
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM Proveedor WHERE id=%s", (id,))
                row = cursor.fetchone()
                return Proveedor(**row) if row else None
        finally:
            DBConnection.close_connection(connection)