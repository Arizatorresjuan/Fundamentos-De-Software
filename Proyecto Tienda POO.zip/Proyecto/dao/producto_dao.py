from util.db_connection import DBConnection
from model.producto import Producto

class ProductoDAO:
    @staticmethod
    def insertar(producto):
        if not producto.validar():
            raise ValueError("Datos de producto inválidos")
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                sql = "INSERT INTO Producto (nombre, descripcion, precio, stock, categoria) VALUES (%s, %s, %s, %s, %s)"
                cursor.execute(sql, (producto.nombre, producto.descripcion, producto.precio, producto.stock, producto.categoria))
                connection.commit()
                producto.id = cursor.lastrowid
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def consultar_todos():
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM Producto")
                results = cursor.fetchall()
                return [Producto(**row) for row in results]
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def actualizar(producto):
        if not producto.validar():
            raise ValueError("Datos de producto inválidos")
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                sql = "UPDATE Producto SET nombre=%s, descripcion=%s, precio=%s, stock=%s, categoria=%s WHERE id=%s"
                cursor.execute(sql, (producto.nombre, producto.descripcion, producto.precio, producto.stock, producto.categoria, producto.id))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def eliminar(id):
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("DELETE FROM Producto WHERE id=%s", (id,))
                connection.commit()
        finally:
            DBConnection.close_connection(connection)

    @staticmethod
    def consultar_por_id(id):
        connection = DBConnection.get_connection()
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM Producto WHERE id=%s", (id,))
                row = cursor.fetchone()
                return Producto(**row) if row else None
        finally:
            DBConnection.close_connection(connection)