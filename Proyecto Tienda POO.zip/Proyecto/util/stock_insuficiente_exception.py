class StockInsuficienteException(Exception):
    def __init__(self, message="Stock insuficiente para la venta"):
        super().__init__(message)