import pymysql

class DBConnection:
    @staticmethod
    def get_connection():
        try:
            connection = pymysql.connect(
                host='localhost',
                user='root',  # Cambia por tu usuario
                password="",  # Cambia por tu contraseña
                database='inventario_ventas',
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )
            return connection
        except pymysql.MySQLError as e:
            raise Exception(f"Error de conexión a DB: {e}")

    @staticmethod
    def close_connection(connection):
        if connection:
            connection.close()