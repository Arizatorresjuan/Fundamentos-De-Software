import tkinter as tk
from tkinter import ttk, messagebox
from controller.proveedor_controller import ProveedorController
from model.proveedor import Proveedor

class ProveedorView:
    def __init__(self, root):
        self.root = root
        self.root.title("🚚 Gestión de Proveedores")
        self.root.geometry("950x650")
        self.root.configure(bg="#f4f6f9")

        # 🟩 Título
        titulo = tk.Label(
            root,
            text="🚚 Gestión de Proveedores",
            font=("Segoe UI", 20, "bold"),
            bg="#27ae60",
            fg="white",
            pady=15
        )
        titulo.pack(fill="x")

        # ----- Tarjeta principal estilo supermercado -----
        card = tk.Frame(root, bg="white", bd=2, relief="groove")
        card.place(relx=0.5, rely=0.25, anchor="center", width=650, height=220)

        label_style = {"font": ("Segoe UI", 11), "bg": "white"}

        # -------- FORMULARIO --------
        tk.Label(card, text="Nombre:", **label_style).grid(row=0, column=0, padx=15, pady=10, sticky="w")
        self.nombre_entry = tk.Entry(card, width=45, bd=2, relief="groove")
        self.nombre_entry.grid(row=0, column=1, pady=10)

        tk.Label(card, text="Contacto:", **label_style).grid(row=1, column=0, padx=15, pady=10, sticky="w")
        self.contacto_entry = tk.Entry(card, width=45, bd=2, relief="groove")
        self.contacto_entry.grid(row=1, column=1, pady=10)

        tk.Label(card, text="Dirección:", **label_style).grid(row=2, column=0, padx=15, pady=10, sticky="w")
        self.direccion_entry = tk.Entry(card, width=45, bd=2, relief="groove")
        self.direccion_entry.grid(row=2, column=1, pady=10)

        # --------- Botones ---------
        btn_frame = tk.Frame(root, bg="#f4f6f9")
        btn_frame.place(relx=0.5, rely=0.45, anchor="center")

        btn_style = {
            "font": ("Segoe UI", 11, "bold"),
            "width": 14,
            "padx": 5,
            "pady": 6,
            "bd": 0,
            "cursor": "hand2"
        }

        tk.Button(btn_frame, text="➕ Agregar", bg="#2ecc71", fg="white",
                  command=self.agregar, **btn_style).grid(row=0, column=0, padx=15)

        tk.Button(btn_frame, text="✏ Actualizar", bg="#f1c40f", fg="white",
                  command=self.actualizar, **btn_style).grid(row=0, column=1, padx=15)

        tk.Button(btn_frame, text="🗑 Eliminar", bg="#e74c3c", fg="white",
                  command=self.eliminar, **btn_style).grid(row=0, column=2, padx=15)

        # -------- Tabla (NO se modificó nada en su posición o tamaño) --------
        table_frame = tk.Frame(root)
        table_frame.place(relx=0.5, rely=0.78, anchor="center", width=900, height=360)

        self.tree = ttk.Treeview(
            table_frame,
            columns=("ID", "Nombre", "Contacto", "Dirección"),
            show="headings",
            height=14
        )

        for col in ("ID", "Nombre", "Contacto", "Dirección"):
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor="center", width=200)

        self.tree.pack(expand=True, fill="both")

        self.cargar_proveedores()

    # ---------------- Métodos CRUD ----------------

    def cargar_proveedores(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        proveedores = ProveedorController.obtener_proveedores()
        for p in proveedores:
            self.tree.insert("", "end", values=(p.id, p.nombre, p.contacto, p.direccion))

    def agregar(self):
        try:
            p = Proveedor(
                nombre=self.nombre_entry.get(),
                contacto=self.contacto_entry.get(),
                direccion=self.direccion_entry.get()
            )
            ProveedorController.crear_proveedor(p)
            self.cargar_proveedores()
            messagebox.showinfo("Éxito", "Proveedor agregado correctamente")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def actualizar(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Advertencia", "Selecciona un proveedor")
            return

        item = self.tree.item(selected)
        id = item['values'][0]

        try:
            p = Proveedor(
                id=id,
                nombre=self.nombre_entry.get(),
                contacto=self.contacto_entry.get(),
                direccion=self.direccion_entry.get()
            )
            ProveedorController.actualizar_proveedor(p)
            self.cargar_proveedores()
            messagebox.showinfo("Éxito", "Proveedor actualizado correctamente")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def eliminar(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Advertencia", "Selecciona un proveedor")
            return

        item = self.tree.item(selected)
        id = item['values'][0]

        ProveedorController.eliminar_proveedor(id)
        self.cargar_proveedores()
        messagebox.showinfo("Éxito", "Proveedor eliminado")
