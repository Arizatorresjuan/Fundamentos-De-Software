import tkinter as tk
from tkinter import ttk, messagebox
from controller.venta_controller import VentaController
from controller.cliente_controller import ClienteController
from controller.producto_controller import ProductoController
from model.venta import Venta
from datetime import date

class VentaView:
    def __init__(self, root):
        self.root = root
        self.root.title("Gestión de Ventas - Supermercado")
        self.root.geometry("900x650")
        self.root.configure(bg="#F5F8F2")

        self.configurar_estilos()

        # ------------------ HEADER ------------------
        header = tk.Frame(self.root, bg="#4CAF50", height=80)
        header.pack(fill="x")

        tk.Label(
            header, text="Gestión de Ventas", 
            font=("Segoe UI", 22, "bold"), bg="#4CAF50", fg="white"
        ).pack(pady=20)

        # ------------------ FORM FRAME ------------------
        form_frame = tk.LabelFrame(
            self.root, text="Registrar Venta", padx=20, pady=20, 
            bg="#F5F8F2", fg="#2E7D32", font=("Segoe UI", 12, "bold")
        )
        form_frame.pack(padx=20, pady=15, fill="x")

        # Cliente
        ttk.Label(form_frame, text="Cliente:", background="#F5F8F2").grid(row=0, column=0, pady=10, sticky="w")
        self.cliente_combo = ttk.Combobox(form_frame, width=40)
        self.cliente_combo.grid(row=0, column=1, pady=10)
        self.cargar_clientes()

        # Producto
        ttk.Label(form_frame, text="Producto:", background="#F5F8F2").grid(row=1, column=0, pady=10, sticky="w")
        self.producto_combo = ttk.Combobox(form_frame, width=40)
        self.producto_combo.grid(row=1, column=1, pady=10)
        self.cargar_productos()

        # Cantidad
        ttk.Label(form_frame, text="Cantidad:", background="#F5F8F2").grid(row=2, column=0, pady=10, sticky="w")
        self.cantidad_entry = ttk.Entry(form_frame, width=20)
        self.cantidad_entry.grid(row=2, column=1, pady=10, sticky="w")

        # Total
        ttk.Label(form_frame, text="Total:", background="#F5F8F2").grid(row=3, column=0, pady=10, sticky="w")
        self.total_label = tk.Label(form_frame, text="$0.00", font=("Segoe UI", 12, "bold"), bg="#F5F8F2")
        self.total_label.grid(row=3, column=1, pady=10, sticky="w")

        # Buttons
        button_frame = tk.Frame(form_frame, bg="#F5F8F2")
        button_frame.grid(row=4, column=0, columnspan=2, pady=10)

        ttk.Button(button_frame, text="Calcular Total", command=self.calcular_total, style="Super.TButton").grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="Agregar", command=self.agregar, style="Success.TButton").grid(row=0, column=1, padx=5)
        ttk.Button(button_frame, text="Actualizar", command=self.actualizar, style="Warning.TButton").grid(row=0, column=2, padx=5)
        ttk.Button(button_frame, text="Eliminar", command=self.eliminar, style="Danger.TButton").grid(row=0, column=3, padx=5)

        # ------------------ TABLE FRAME ------------------
        table_frame = tk.LabelFrame(self.root, text="Listado de Ventas", padx=15, pady=15, bg="#F5F8F2", fg="#2E7D32", font=("Segoe UI", 12, "bold"))
        table_frame.pack(padx=20, pady=10, fill="both", expand=True)

        self.tree = ttk.Treeview(table_frame, columns=("ID", "Fecha", "Cliente", "Producto", "Cantidad", "Precio Total"), show="headings", height=15)
        self.tree.pack(fill="both", expand=True)

        for col in ("ID", "Fecha", "Cliente", "Producto", "Cantidad", "Precio Total"):
            self.tree.heading(col, text=col)

        self.cargar_ventas()

    # ------------------ ESTILOS ------------------
    def configurar_estilos(self):
        style = ttk.Style()

        style.theme_use("clam")

        style.configure("Super.TButton", 
                        font=("Segoe UI", 11, "bold"), 
                        padding=8)

        style.configure("Success.TButton", 
                        background="#4CAF50", 
                        foreground="white",
                        font=("Segoe UI", 11, "bold"), 
                        padding=8)
        style.map("Success.TButton", background=[("active", "#45A049")])

        style.configure("Warning.TButton", 
                        background="#FFC107", 
                        foreground="black",
                        font=("Segoe UI", 11, "bold"), 
                        padding=8)
        style.map("Warning.TButton", background=[("active", "#E0A800")])

        style.configure("Danger.TButton", 
                        background="#F44336", 
                        foreground="white",
                        font=("Segoe UI", 11, "bold"), 
                        padding=8)
        style.map("Danger.TButton", background=[("active", "#D32F2F")])

        style.configure("Treeview", 
                        background="white",
                        foreground="black",
                        rowheight=28,
                        fieldbackground="white")

        style.map("Treeview", background=[("selected", "#A5D6A7")])

    # ------------------ FUNCIONES ------------------
    def cargar_clientes(self):
        clientes = ClienteController.obtener_clientes()
        self.cliente_combo["values"] = [f"{c.id} - {c.nombre}" for c in clientes]

    def cargar_productos(self):
        productos = ProductoController.obtener_productos()
        self.producto_combo["values"] = [f"{p.id} - {p.nombre}" for p in productos]

    def cargar_ventas(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        ventas = VentaController.obtener_ventas()

        clientes = ClienteController.obtener_clientes()
        productos = ProductoController.obtener_productos()

        for v in ventas:
            cli = next((c.nombre for c in clientes if c.id == v.cliente_id), "")
            prod = next((p.nombre for p in productos if p.id == v.producto_id), "")
            self.tree.insert("", "end", values=(v.id, v.fecha, cli, prod, v.cantidad, v.precio_total))

    def calcular_total(self):
        try:
            prod_id = int(self.producto_combo.get().split(" - ")[0])
            cantidad = int(self.cantidad_entry.get())

            productos = ProductoController.obtener_productos()
            prod = next((p for p in productos if p.id == prod_id), None)

            if prod:
                total = prod.precio * cantidad
                self.total_label.config(text=f"${total:.2f}")
        except:
            self.total_label.config(text="$0.00")

    def agregar(self):
        try:
            cli_id = int(self.cliente_combo.get().split(" - ")[0])
            prod_id = int(self.producto_combo.get().split(" - ")[0])
            cantidad = int(self.cantidad_entry.get())
            total = float(self.total_label.cget("text").replace("$", ""))

            v = Venta(fecha=date.today(), cliente_id=cli_id, producto_id=prod_id, cantidad=cantidad, precio_total=total)
            VentaController.crear_venta(v)
            self.cargar_ventas()

            messagebox.showinfo("Éxito", "Venta agregada correctamente")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def actualizar(self):
        selected = self.tree.selection()
        if not selected:
            return messagebox.showwarning("Advertencia", "Seleccione una venta")

        id = self.tree.item(selected)["values"][0]

        try:
            cli_id = int(self.cliente_combo.get().split(" - ")[0])
            prod_id = int(self.producto_combo.get().split(" - ")[0])
            cantidad = int(self.cantidad_entry.get())
            total = float(self.total_label.cget("text").replace("$", ""))

            v = Venta(id=id, fecha=date.today(), cliente_id=cli_id, producto_id=prod_id, cantidad=cantidad, precio_total=total)
            VentaController.actualizar_venta(v)
            self.cargar_ventas()

            messagebox.showinfo("Éxito", "Venta actualizada correctamente")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def eliminar(self):
        selected = self.tree.selection()
        if not selected:
            return messagebox.showwarning("Advertencia", "Seleccione una venta")

        id = self.tree.item(selected)["values"][0]
        VentaController.eliminar_venta(id)
        self.cargar_ventas()
        messagebox.showinfo("Éxito", "Venta eliminada correctamente")
