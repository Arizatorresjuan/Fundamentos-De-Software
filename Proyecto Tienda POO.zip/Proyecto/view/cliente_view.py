import tkinter as tk
from tkinter import ttk, messagebox
from controller.cliente_controller import ClienteController
from model.cliente import Cliente

class ClienteView:

    def __init__(self, root):
        self.root = root
        self.root.title("🧑‍🤝‍🧑 Gestión de Clientes - Supermercado")
        self.root.geometry("900x600")
        self.root.configure(bg="#F4F7F5")  # tono retail suave

        # --------------------- Estilos ---------------------
        style = ttk.Style()
        style.theme_use("clam")

        style.configure("Form.TLabel",
                        font=("Segoe UI", 11),
                        background="white",
                        foreground="#2C3E50")

        style.configure("Form.TEntry",
                        padding=5)

        style.configure("Super.TButton",
                        font=("Segoe UI", 11, "bold"),
                        background="#27AE60",
                        foreground="white",
                        padding=10)
        style.map("Super.TButton",
                  background=[("active", "#1E8449")])

        style.configure("Treeview.Heading",
                        font=("Segoe UI Semibold", 11),
                        background="#27AE60",
                        foreground="white")

        style.configure("Treeview",
                        font=("Segoe UI", 10),
                        rowheight=28)

        # --------------------- Layout general ---------------------
        main_frame = tk.Frame(root, bg="#F4F7F5")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        title = tk.Label(main_frame,
                         text="Gestión de Clientes",
                         font=("Segoe UI Semibold", 22),
                         bg="#F4F7F5",
                         fg="#2C3E50")
        title.pack(pady=10)

        # --------------------- Contenedor Formulario ---------------------
        form_card = tk.Frame(main_frame, bg="white", relief="groove", bd=2)
        form_card.pack(fill="x", padx=10, pady=15, ipady=10)

        form = tk.Frame(form_card, bg="white")
        form.pack(pady=10)

        # Nombre
        ttk.Label(form, text="Nombre:", style="Form.TLabel").grid(row=0, column=0, sticky="e", padx=10, pady=5)
        self.nombre_entry = ttk.Entry(form, width=35, style="Form.TEntry")
        self.nombre_entry.grid(row=0, column=1, pady=5)

        # Contacto
        ttk.Label(form, text="Contacto:", style="Form.TLabel").grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.contacto_entry = ttk.Entry(form, width=35)
        self.contacto_entry.grid(row=1, column=1, pady=5)

        # Dirección
        ttk.Label(form, text="Dirección:", style="Form.TLabel").grid(row=2, column=0, sticky="e", padx=10, pady=5)
        self.direccion_entry = ttk.Entry(form, width=35)
        self.direccion_entry.grid(row=2, column=1, pady=5)

        # --------------------- Botones del formulario ---------------------
        btn_frame = tk.Frame(form_card, bg="white")
        btn_frame.pack(pady=10)

        ttk.Button(btn_frame, text="Agregar", style="Super.TButton",
                   command=self.agregar).grid(row=0, column=0, padx=15)

        ttk.Button(btn_frame, text="Actualizar", style="Super.TButton",
                   command=self.actualizar).grid(row=0, column=1, padx=15)

        ttk.Button(btn_frame, text="Eliminar", style="Super.TButton",
                   command=self.eliminar).grid(row=0, column=2, padx=15)

        # --------------------- Tabla ---------------------
        table_frame = tk.Frame(main_frame, bg="#F4F7F5")
        table_frame.pack(fill="both", expand=True, pady=10)

        self.tree = ttk.Treeview(
            table_frame,
            columns=("ID", "Nombre", "Contacto", "Dirección"),
            show="headings"
        )
        self.tree.pack(fill="both", expand=True)

        for col in ("ID", "Nombre", "Contacto", "Dirección"):
            self.tree.heading(col, text=col)

        self.cargar_clientes()

    # --------------------- Funciones CRUD ---------------------
    def cargar_clientes(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        clientes = ClienteController.obtener_clientes()
        for c in clientes:
            self.tree.insert("", "end",
                             values=(c.id, c.nombre, c.contacto, c.direccion))

    def agregar(self):
        try:
            c = Cliente(
                nombre=self.nombre_entry.get(),
                contacto=self.contacto_entry.get(),
                direccion=self.direccion_entry.get()
            )
            ClienteController.crear_cliente(c)
            self.cargar_clientes()
            messagebox.showinfo("Éxito", "Cliente agregado correctamente")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def actualizar(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Advertencia", "Selecciona un cliente.")
            return

        item = self.tree.item(selected)
        id = item['values'][0]

        try:
            c = Cliente(
                id=id,
                nombre=self.nombre_entry.get(),
                contacto=self.contacto_entry.get(),
                direccion=self.direccion_entry.get()
            )
            ClienteController.actualizar_cliente(c)
            self.cargar_clientes()
            messagebox.showinfo("Éxito", "Cliente actualizado")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def eliminar(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Advertencia", "Selecciona un cliente.")
            return

        item = self.tree.item(selected)
        id = item['values'][0]

        ClienteController.eliminar_cliente(id)
        self.cargar_clientes()
        messagebox.showinfo("Éxito", "Cliente eliminado")
