import tkinter as tk
from tkinter import ttk, messagebox
from controller.producto_controller import ProductoController
from model.producto import Producto

class ProductoView:
    def __init__(self, root):
        self.root = root
        self.root.title("🛒 Gestión de Productos - Supermercado")
        self.root.geometry("900x650")
        self.root.configure(bg="#f4f6f9")  # Fondo suave gris claro

        # ---------- TÍTULO PRINCIPAL ----------
        title = tk.Label(
            root,
            text="📦 Gestión de Productos",
            font=("Segoe UI", 22, "bold"),
            bg="#2ecc71",   # Verde principal
            fg="white",
            pady=15
        )
        title.pack(fill="x")

        # ---------- CARD DE FORMULARIO ----------
        form_frame = tk.Frame(root, bg="white", bd=2, relief="groove")
        form_frame.pack(pady=20)

        etiquetas = ["Nombre:", "Descripción:", "Precio:", "Stock:", "Categoría:"]
        self.entries = []

        for i, texto in enumerate(etiquetas):
            tk.Label(
                form_frame, text=texto,
                font=("Segoe UI", 11),
                bg="white"
            ).grid(row=i, column=0, padx=10, pady=8, sticky="w")

            entry = tk.Entry(form_frame, font=("Segoe UI", 11), width=40)
            entry.grid(row=i, column=1, padx=10, pady=8)
            self.entries.append(entry)

        self.nombre_entry, self.descripcion_entry, self.precio_entry, self.stock_entry, self.categoria_entry = self.entries

        # ---------- BOTONES (estilo supermercado) ----------
        btn_frame = tk.Frame(root, bg="#f4f6f9")
        btn_frame.pack(pady=10)

        tk.Button(
            btn_frame, text="➕ Agregar", command=self.agregar,
            bg="#2ecc71", fg="white",
            font=("Segoe UI", 11, "bold"),
            padx=15, pady=8
        ).grid(row=0, column=0, padx=10)

        tk.Button(
            btn_frame, text="✏ Actualizar", command=self.actualizar,
            bg="#f1c40f", fg="white",
            font=("Segoe UI", 11, "bold"),
            padx=15, pady=8
        ).grid(row=0, column=1, padx=10)

        tk.Button(
            btn_frame, text="🗑 Eliminar", command=self.eliminar,
            bg="#e74c3c", fg="white",
            font=("Segoe UI", 11, "bold"),
            padx=15, pady=8
        ).grid(row=0, column=2, padx=10)

        # ---------- TABLA DE PRODUCTOS ----------
        table_frame = tk.Frame(root, bg="#f4f6f9")
        table_frame.pack(pady=10, padx=20, fill="both", expand=True)

        columnas = ("ID", "Nombre", "Descripción", "Precio", "Stock", "Categoría")

        style = ttk.Style()
        style.configure("Treeview", font=("Segoe UI", 10))
        style.configure("Treeview.Heading", font=("Segoe UI", 11, "bold"), background="#2ecc71")

        self.tree = ttk.Treeview(table_frame, columns=columnas, show="headings", height=12)
        self.tree.pack(fill="both", expand=True)

        for col in columnas:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=130, anchor="center")

        self.tree.bind("<<TreeviewSelect>>", self.seleccionar_fila)

        self.cargar_productos()

    # ---------- LLENAR TABLA ----------
    def cargar_productos(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        productos = ProductoController.obtener_productos()

        for p in productos:
            self.tree.insert("", "end", values=(
                p.id, p.nombre, p.descripcion, p.precio, p.stock, p.categoria
            ))

    # ---------- AUTOLLENAR CAMPOS ----------
    def seleccionar_fila(self, event):
        selected = self.tree.selection()
        if not selected:
            return

        item = self.tree.item(selected)
        valores = item["values"]

        entries = [
            self.nombre_entry,
            self.descripcion_entry,
            self.precio_entry,
            self.stock_entry,
            self.categoria_entry
        ]

        for entry, val in zip(entries, valores[1:]):
            entry.delete(0, tk.END)
            entry.insert(0, val)

    # ---------- BOTÓN AGREGAR ----------
    def agregar(self):
        try:
            p = Producto(
                nombre=self.nombre_entry.get(),
                descripcion=self.descripcion_entry.get(),
                precio=float(self.precio_entry.get()),
                stock=int(self.stock_entry.get()),
                categoria=self.categoria_entry.get()
            )
            ProductoController.crear_producto(p)
            self.cargar_productos()
            messagebox.showinfo("Éxito", "Producto agregado correctamente")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    # ---------- BOTÓN ACTUALIZAR ----------
    def actualizar(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Advertencia", "Selecciona un producto")
            return

        item = self.tree.item(selected)
        id = item["values"][0]

        try:
            p = Producto(
                id=id,
                nombre=self.nombre_entry.get(),
                descripcion=self.descripcion_entry.get(),
                precio=float(self.precio_entry.get()),
                stock=int(self.stock_entry.get()),
                categoria=self.categoria_entry.get()
            )
            ProductoController.actualizar_producto(p)
            self.cargar_productos()
            messagebox.showinfo("Éxito", "Producto actualizado")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    # ---------- BOTÓN ELIMINAR ----------
    def eliminar(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Advertencia", "Selecciona un producto")
            return

        item = self.tree.item(selected)
        id = item["values"][0]

        ProductoController.eliminar_producto(id)
        self.cargar_productos()
        messagebox.showinfo("Éxito", "Producto eliminado")
