import tkinter as tk
from tkinter import ttk, messagebox
from controller.compra_controller import CompraController
from controller.proveedor_controller import ProveedorController
from controller.producto_controller import ProductoController
from model.compra import Compra
from datetime import date

class CompraView:

    def __init__(self, root):
        self.root = root
        self.root.title("🛒 Gestión de Compras - Supermercado")
        self.root.geometry("900x620")
        self.root.configure(bg="#F4F7F5")

        # --------------------- Estilos ---------------------
        style = ttk.Style()
        style.theme_use("clam")

        style.configure("Form.TLabel",
                        font=("Segoe UI", 11),
                        background="white",
                        foreground="#2C3E50")

        style.configure("Super.TButton",
                        font=("Segoe UI", 11, "bold"),
                        background="#27AE60",
                        foreground="white",
                        padding=10)
        style.map("Super.TButton",
                  background=[("active", "#1E8449")])

        style.configure("Treeview.Heading",
                        font=("Segoe UI Semibold", 11),
                        background="#27AE60",
                        foreground="white")

        style.configure("Treeview",
                        font=("Segoe UI", 10),
                        rowheight=28)

        # --------------------- Layout general ---------------------
        main_frame = tk.Frame(root, bg="#F4F7F5")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        title = tk.Label(main_frame,
                         text="Gestión de Compras",
                         font=("Segoe UI Semibold", 22),
                         bg="#F4F7F5",
                         fg="#2C3E50")
        title.pack(pady=10)

        # --------------------- Contenedor Formulario ---------------------
        form_card = tk.Frame(main_frame, bg="white", relief="groove", bd=2)
        form_card.pack(fill="x", padx=10, pady=15, ipady=10)

        form = tk.Frame(form_card, bg="white")
        form.pack(pady=10)

        # Proveedor
        ttk.Label(form, text="Proveedor:", style="Form.TLabel").grid(row=0, column=0, sticky="e", padx=10, pady=5)
        self.proveedor_combo = ttk.Combobox(form, width=35, state="readonly")
        self.proveedor_combo.grid(row=0, column=1, pady=5)
        self.cargar_proveedores()

        # Producto
        ttk.Label(form, text="Producto:", style="Form.TLabel").grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.producto_combo = ttk.Combobox(form, width=35, state="readonly")
        self.producto_combo.grid(row=1, column=1, pady=5)
        self.cargar_productos()

        # Cantidad
        ttk.Label(form, text="Cantidad:", style="Form.TLabel").grid(row=2, column=0, sticky="e", padx=10, pady=5)
        self.cantidad_entry = ttk.Entry(form, width=35)
        self.cantidad_entry.grid(row=2, column=1, pady=5)

        # Precio total
        ttk.Label(form, text="Precio Total:", style="Form.TLabel").grid(row=3, column=0, sticky="e", padx=10, pady=5)
        self.precio_total_entry = ttk.Entry(form, width=35)
        self.precio_total_entry.grid(row=3, column=1, pady=5)

        # --------------------- Botones del formulario ---------------------
        btn_frame = tk.Frame(form_card, bg="white")
        btn_frame.pack(pady=10)

        ttk.Button(btn_frame, text="Agregar", style="Super.TButton",
                   command=self.agregar).grid(row=0, column=0, padx=15)

        ttk.Button(btn_frame, text="Actualizar", style="Super.TButton",
                   command=self.actualizar).grid(row=0, column=1, padx=15)

        ttk.Button(btn_frame, text="Eliminar", style="Super.TButton",
                   command=self.eliminar).grid(row=0, column=2, padx=15)

        # --------------------- Tabla ---------------------
        table_frame = tk.Frame(main_frame, bg="#F4F7F5")
        table_frame.pack(fill="both", expand=True, pady=10)

        self.tree = ttk.Treeview(
            table_frame,
            columns=("ID", "Fecha", "Proveedor", "Producto", "Cantidad", "Precio Total"),
            show="headings"
        )
        self.tree.pack(fill="both", expand=True)

        for col in ("ID", "Fecha", "Proveedor", "Producto", "Cantidad", "Precio Total"):
            self.tree.heading(col, text=col)

        self.cargar_compras()

    # --------------------- Cargar datos ---------------------
    def cargar_proveedores(self):
        proveedores = ProveedorController.obtener_proveedores()
        self.proveedor_combo['values'] = [f"{p.id} - {p.nombre}" for p in proveedores]

    def cargar_productos(self):
        productos = ProductoController.obtener_productos()
        self.producto_combo['values'] = [f"{p.id} - {p.nombre}" for p in productos]

    def cargar_compras(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        compras = CompraController.obtener_compras()
        proveedores = ProveedorController.obtener_proveedores()
        productos = ProductoController.obtener_productos()

        for c in compras:
            prov_nombre = next((p.nombre for p in proveedores if p.id == c.proveedor_id), "")
            prod_nombre = next((p.nombre for p in productos if p.id == c.producto_id), "")

            self.tree.insert("", "end",
                             values=(c.id, c.fecha, prov_nombre, prod_nombre, c.cantidad, c.precio_total))

    # --------------------- CRUD ---------------------
    def agregar(self):
        try:
            prov_id = int(self.proveedor_combo.get().split(" - ")[0])
            prod_id = int(self.producto_combo.get().split(" - ")[0])

            c = Compra(
                fecha=date.today(),
                proveedor_id=prov_id,
                producto_id=prod_id,
                cantidad=int(self.cantidad_entry.get()),
                precio_total=float(self.precio_total_entry.get())
            )

            CompraController.crear_compra(c)
            self.cargar_compras()
            messagebox.showinfo("Éxito", "Compra agregada exitosamente")

        except Exception as e:
            messagebox.showerror("Error", str(e))

    def actualizar(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Advertencia", "Selecciona una compra")
            return

        item = self.tree.item(selected)
        id = item['values'][0]

        try:
            prov_id = int(self.proveedor_combo.get().split(" - ")[0])
            prod_id = int(self.producto_combo.get().split(" - ")[0])

            c = Compra(
                id=id,
                fecha=date.today(),
                proveedor_id=prov_id,
                producto_id=prod_id,
                cantidad=int(self.cantidad_entry.get()),
                precio_total=float(self.precio_total_entry.get())
            )

            CompraController.actualizar_compra(c)
            self.cargar_compras()
            messagebox.showinfo("Éxito", "Compra actualizada")

        except Exception as e:
            messagebox.showerror("Error", str(e))

    def eliminar(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Advertencia", "Selecciona una compra")
            return

        item = self.tree.item(selected)
        id = item['values'][0]

        CompraController.eliminar_compra(id)
        self.cargar_compras()
        messagebox.showinfo("Éxito", "Compra eliminada")
