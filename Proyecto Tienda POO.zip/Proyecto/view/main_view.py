import tkinter as tk
from tkinter import ttk

from view.producto_view import ProductoView
from view.proveedor_view import ProveedorView
from view.cliente_view import ClienteView
from view.compra_view import CompraView
from view.venta_view import VentaView


class MainView:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Inventarios y Ventas")
        self.root.geometry("1000x650")
        self.root.configure(bg="#F4F7F5") 

        style = ttk.Style()
        style.theme_use("clam")

        style.configure(
            "Menu.TButton",
            font=("Segoe UI", 12),
            foreground="white",
            background="#27AE60", 
            padding=(20, 17),
            relief="flat"
        )
        style.map("Menu.TButton", background=[("active", "#1E8449")]) 

        style.configure("Card.TFrame", background="white", relief="groove", borderwidth=1)
        style.configure("Header.TLabel", font=("Segoe UI Semibold", 22),
                        background="#F4F7F5", foreground="#2C3E50")
        style.configure("Metric.TLabel", font=("Segoe UI", 14),
                        background="white", foreground="#1E8449")
        style.configure("MetricNum.TLabel", font=("Segoe UI Semibold", 26),
                        background="white", foreground="#2C3E50")

   
        sidebar = tk.Frame(self.root, bg="#27AE60", width=240)
        sidebar.pack(side="left", fill="y")

        main_area = tk.Frame(self.root, bg="#F4F7F5")
        main_area.pack(side="right", fill="both", expand=True)

        ttk.Label(main_area, text="Panel Principal del Gestor de Inventarios",
                  style="Header.TLabel").pack(pady=30)

     
        dashboard = tk.Frame(main_area, bg="#F4F7F5")
        dashboard.pack(pady=20)


        tk.Label(
            main_area,
            text="Bienvenido al Sistema de Gestión de Inventarios.\nUse el menú lateral para navegar.",
            font=("Segoe UI", 12),
            bg="#F4F7F5", fg="#2C3E50"
        ).pack(pady=20)

        ttk.Button(sidebar, text="🛒 Ventas", style="Menu.TButton",
                   command=self.abrir_ventas).pack(fill="x", pady=5)
        ttk.Button(sidebar, text="📦 Productos", style="Menu.TButton",
                   command=self.abrir_productos).pack(fill="x", pady=5)
        ttk.Button(sidebar, text="🚚 Proveedores", style="Menu.TButton",
                   command=self.abrir_proveedores).pack(fill="x", pady=5)
        ttk.Button(sidebar, text="👥 Clientes", style="Menu.TButton",
                   command=self.abrir_clientes).pack(fill="x", pady=5)
        ttk.Button(sidebar, text="📥 Compras", style="Menu.TButton",
                   command=self.abrir_compras).pack(fill="x", pady=5)
        ttk.Button(sidebar, text="🔚 Salir", style="Menu.TButton",
                   command=self.root.quit).pack(fill="x", pady=5)

    def abrir_productos(self):
        ProductoView(tk.Toplevel(self.root))

    def abrir_proveedores(self):
        ProveedorView(tk.Toplevel(self.root))

    def abrir_clientes(self):
        ClienteView(tk.Toplevel(self.root))

    def abrir_compras(self):
        CompraView(tk.Toplevel(self.root))

    def abrir_ventas(self):
        VentaView(tk.Toplevel(self.root))
